import React from "react";
import { MdDeleteForever } from "react-icons/md";
import { FaSquareCheck } from "react-icons/fa6";
import { ImCross } from "react-icons/im";
import { FaEdit } from "react-icons/fa";
import './ShowActivity.css';

const ShowActivity = ({
  todolist,
  handleToggle,
  handleDeleteToggle,
  removeAll,
  editActivity,
}) => {
  return (
    <>
      <div className="activity-list-container">
        <h1 className="heading">Activity List</h1>
        <table className="activity-table">
          <thead>
            <tr>
              <th>Task Name</th>
              <th>Status</th>
              <th>Delete</th>
              <th>Edit</th>
            </tr>
          </thead>
          <tbody>
            {todolist.map((activityitem) => (
              <tr key={activityitem.id}>
                <td>{activityitem.taskName}</td>
                <td>
                  {activityitem.status ? (
                    <ImCross onClick={() => handleToggle(activityitem.id)} />
                  ) : (
                    <FaSquareCheck
                      onClick={() => handleToggle(activityitem.id)}
                    />
                  )}
                </td>
                <td>
                  <MdDeleteForever
                    onClick={() => handleDeleteToggle(activityitem.id)}
                  />
                  </td>
                  <td>
                  <FaEdit onClick={() => editActivity(activityitem.id)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {todolist.length >= 1 && (
          <div className="dl-btn">
            <button onClick={removeAll}>Delete All</button>
          </div>
        )}
      </div>
    </>
  );
};

export default ShowActivity;
