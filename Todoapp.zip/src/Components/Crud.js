import React, { useEffect, useState } from "react";
import "./ShowActivity";
import ShowActivity from "./ShowActivity";
import Axios from "axios"; // Changed import to Axios
import './Crud.css'

function Crud() {
  const [activity, setActivity] = useState("");
  const [todolist, setToDoList] = useState([]);
  const [editItemId, setEditItemId] = useState(null);

  useEffect(
    () => {
      async function fetchData() {
        try {
          const result = await Axios.get("http://localhost:8090/getAll");
          setToDoList(result.data);
        } catch (error) {
          console.log(error);
        }
      }
      fetchData();
    }, [todolist]
  );

  const addActivity = async () => {
    const newToDoActivity = {
      taskName: activity,
      status: false,
    };
    try {
      const result = await Axios.post("http://localhost:8090/save", newToDoActivity);
      console.log(result.data);
    } catch (error) {
      console.log(error);
    }
    setActivity("");
  };

  const handleToggle = async (itemId) => {
    const updatedToDoList = todolist.map(activityitem => {
      if (activityitem.id === itemId) {
        const statusNew = !activityitem.status;
        return {
          ...activityitem,
          status: statusNew
        };
      }
      return activityitem;
    });
    try {
      await Axios.put("http://localhost:8090/put", updatedToDoList.find(item => item.id === itemId));
    } catch (error) {
      console.log(error);
    }
  };

  const handleDeleteToggle = async (itemId) => {
    try {
      await Axios.delete(`http://localhost:8090/delete?id=${itemId}`);
    } catch (error) {
      console.log(error);
    }
  };

  const removeAll = async () => {
    try {
      await Axios.delete(`http://localhost:8090/deleteAll`);
    } catch (error) {
      console.log(error);
    }
  };

  const editActivity = (itemId) => {
    setEditItemId(itemId);
    setActivity(todolist.find((activityitem) => activityitem.id === itemId).taskName);
  };

  const editActivityItem = async () => {
    const updatedToDoList = todolist.map(activityitem => {
      if (activityitem.id === editItemId) {
        return {
          ...activityitem,
          taskName: activity
        };
      }
      return activityitem;
    });
    try {
      await Axios.put("http://localhost:8090/put", updatedToDoList.find(item => item.id === editItemId));
      setEditItemId(null);
      setActivity("");
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div className="Add-activity">
        <label>Activity</label>
        <input
          type="text"
          placeholder="Add Your Activity"
          value={activity}
          onChange={(e) => setActivity(e.target.value)}
        />
        {editItemId ? (
          <button onClick={editActivityItem}>Edit</button>
        ) : (
          <button onClick={addActivity}>Add</button>
        )}
        <ShowActivity
          todolist={todolist}
          handleToggle={handleToggle}
          handleDeleteToggle={handleDeleteToggle}
          removeAll={removeAll}
          editActivity={editActivity}
        />
      </div>
    </>
  );
}

export default Crud;
