import React from "react";
import "./AboutUs.css";
const Aboutus = () => {
  return (
    <div className="about">
      <h1>About Us</h1>
      
      <p>
        In this To do Application... , we are passionate about helping individuals organize
        and manage their daily activities efficiently.
      </p>
    </div>
  );
};

export default Aboutus;
