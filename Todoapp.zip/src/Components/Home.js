import React from 'react'
import './Home.css'

function Home() {
  return (
    <div className='home'>
        <h1>Welcome to the Todo Application!</h1>
    </div>
  )
}

export default Home