package com.ToDo.ToDoApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ToDo.ToDoApp.dto.Task;

public interface TaskRepository extends JpaRepository<Task,Integer> {

}
