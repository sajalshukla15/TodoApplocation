package com.ToDo.ToDoApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ToDo.ToDoApp.dto.Task;
import com.ToDo.ToDoApp.repository.TaskRepository;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class TaskController 
{
	@Autowired
	TaskRepository tr;
	@GetMapping("/getAll")
	public List<Task> getAll()
	{
		List<Task> t=tr.findAll();
		return t;
	}
	@DeleteMapping("/delete")
	public String deletById(@RequestParam int id)
	{
		tr.deleteById(id);
		return "deleted";
	}
	
	@DeleteMapping("/deleteAll")
	public String deleteAll()
	{
		tr.deleteAll();
		return "deleted";
	}
	/*
	 * @PostMapping("/save") public String save(@RequestBody Task task) { try {
	 * tr.save(task); return "Task saved"; } catch (Exception e) { return
	 * "Error saving task: " + e.getMessage(); } }
	 */
	@PostMapping("/save")
	public String save(@RequestBody Task task) {
	    try {
	        tr.save(task);
	        return "Task saved";
	    } catch (Exception e) {
	        return "Error saving task: " + e.getMessage();
	    }
	}
	@PutMapping("/put")
	public String putTask(@RequestBody Task t)
	{
		tr.save(t);
		return "task changed";
	}
}
